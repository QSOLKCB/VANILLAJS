# VANILLAJS — local RTX 5060 Ti full-path validation

Baseline: 240617e8bc1a935f05eaf75a10531f194f72a173
Candidate: 3f5518a168652a003e8db9aa6dc0371ddb4782ea
Native WebGL: ANGLE (NVIDIA Corporation, NVIDIA GeForce RTX 5060 Ti/PCIe/SSE2, OpenGL ES 3.2)
NVIDIA driver: 595.99.02

| Metric | Baseline median | Candidate median | Scope |
| --- | ---: | ---: | --- |
| CPU static geometry preparation | 57.300 | 13.700 | ms per recorded trial |
| CPU static collision queries, index-build included | 74.400 | 2.000 | ms per recorded trial |
| Actual FPS Lab JS callback | 0.200 | 0.200 | ms per recorded trial |
| Actual FPS Lab frame interval p95 | 16.800 | 16.800 | ms per recorded trial |
| FPS Lab GPU upload submitted bytes | 1486080.000 | 1486080.000 | bytes per recorded trial |
| FPS Lab draw calls | 960.000 | 960.000 | calls per recorded trial |

Native pixel parity: PASS on three deterministic GPU scenes.
CPU geometry and canonical collision receipt hashes: PASS across seven paired trials.

Memory: CDP *statistical sampled allocation* baseline 57195512 bytes, candidate 54949492 bytes; NOT exact process allocation.

Full raw samples and instrument limitations are in report.json.
This file is an observation receipt, not a release/merge gate or independent hardware attestation.
