# RTX 5060 Ti — ARCADE frame-gate hardware comparison

Status: PASS
Candidate: 3f5518a168652a003e8db9aa6dc0371ddb4782ea

## Historical source comparison (same *original* workload rerun)

| Baseline version | Source commit | Candidate commit | Native WebGL pixel parity |
| --- | --- | --- | --- |
| RTX5060TI-001 | 240617e8bc1a935f05eaf75a10531f194f72a173 | 3f5518a168652a003e8db9aa6dc0371ddb4782ea | PASS |
| RTX5060TI-002 | b39b0bd0db5ba9b467b9e47aede4edc4dd156e9f | 3f5518a168652a003e8db9aa6dc0371ddb4782ea | PASS |

Both historical ZIPs were checked by exact outer SHA-256.
The new report re-executes the original workload on the current hardware.
Historic archived timing samples are not substituted into new pairs.

## New opt-in ARCADE frame gate vs forced redraw

| Strategy | Median ms (48 synthetic frames + pixel readback) | Draw calls |
| --- | ---: | ---: |
| Forced | 10.400 | 48 |
| Gated | 10.000 | 9 |

9 pixel checkpoints per trial, 7 alternating paired trials: PASS.
39 of 48 redundant draws skipped; no claim of native game FPS gains.
The new feature was not measured by either archived receipt.
gl.finish and readPixels affect CPU+driver wall time, not pure GPU timer time.
The full raw samples, source SHA and driver/browser metadata are in JSON.

A separate reviewed evidence-preservation PR is required after owner approval.
