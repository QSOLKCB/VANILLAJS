# RTX 5060 Ti — 2D Foundry hardware follow-up

Status: PASS
Exact reviewed main: 4aaa87971068a603b49e72799a6c7ef0615e8305
Native identity: ANGLE (NVIDIA Corporation, NVIDIA GeForce RTX 5060 Ti/PCIe/SSE2, OpenGL ES 3.2)
Seven forced-redraw/FrameGate pairs with matching pixels.
95 observed requestAnimationFrame intervals (browser-scheduler dependent).
Audio and ternary workload evidence is CPU-only.
No universal game FPS or GPU compute speedup claim.
