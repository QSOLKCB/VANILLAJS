# VANILLAJS — local RTX 5060 Ti full-path validation

Baseline: 1f965f4e5b6669de0f954e3a39b11aa679e56720
Candidate: b39b0bd0db5ba9b467b9e47aede4edc4dd156e9f
Native WebGL: ANGLE (NVIDIA Corporation, NVIDIA GeForce RTX 5060 Ti/PCIe/SSE2, OpenGL ES 3.2)
NVIDIA driver: 595.99.02

| Metric | Baseline median | Candidate median | Scope |
| --- | ---: | ---: | --- |
| CPU static geometry preparation | 68.400 | 13.200 | ms per recorded trial |
| CPU static collision queries, index-build included | 72.100 | 2.100 | ms per recorded trial |
| Actual FPS Lab JS callback | 0.300 | 0.300 | ms per recorded trial |
| Actual FPS Lab frame interval p95 | 16.800 | 16.800 | ms per recorded trial |
| FPS Lab GPU upload submitted bytes | 1486080.000 | 1486080.000 | bytes per recorded trial |
| FPS Lab draw calls | 960.000 | 960.000 | calls per recorded trial |

Native pixel parity: PASS on three deterministic GPU scenes.
CPU geometry and canonical collision receipt hashes: PASS across seven paired trials.

Memory: CDP *statistical sampled allocation* baseline 66200540 bytes, candidate 56319816 bytes; NOT exact process allocation.

Full raw samples and instrument limitations are in report.json.
This file is an observation receipt, not a release/merge gate or independent hardware attestation.
