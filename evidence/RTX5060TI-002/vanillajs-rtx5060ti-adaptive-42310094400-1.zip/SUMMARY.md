# RTX 5060 Ti — adaptive donor follow-up (new evidence, not RTX5060TI-001)

Status: PASS
Candidate: b39b0bd0db5ba9b467b9e47aede4edc4dd156e9f
Original preserved baseline ZIP SHA-256: 1a45f75dcc6050189591f0de187745325076712ee4e60e9168ef9c6a5d75f1b8
Historical source candidate: 240617e8bc1a935f05eaf75a10531f194f72a173
Existing baseline reference: 1f965f4e5b6669de0f954e3a39b11aa679e56720
New workload has **no historical RTX5060TI-001 equivalent**.

## Fresh serial 2D circle-query workload

| Circles | Brute (ms) | Grid (ms) | Adaptive (ms) |
| ---: | ---: | ---: | ---: |
| 14 | 0.200 | 0.300 | 0.300 |
| 26 | 0.400 | 0.300 | 0.400 |
| 58 | 1.100 | 0.300 | 0.300 |
| 128 | 1.700 | 0.300 | 0.300 |

## Native GPU cuboid comparison (same new source, 32 frames per trial)

| Strategy | Median CPU+driver completion ms |
| --- | ---: |
| Forced-fresh | 17.500 |
| Retained | 3.700 |

Pixel parity SHA-256: 585d83fc4727162003cb381ffe1613895aa1b3a443c0708d69641159609dec2a

## Evidence semantics

- Native GPU tests use headed Chromium with RTX identification and explicit focus checks.
- Native GPU timing uses gl.finish(); this is **not** a GPU timer query.
- Exact source hashes, all seven paired measurements, renderer identity, and deterministic call counts are in the JSON files.
- The original hardware receipt is verified and referenced, **not overwritten**.
- Report regressions or equivalence alongside speedups; one execution does not establish universal performance.
- Save the resulting GitHub artifact ZIP *verbatim* and its actual SHA-256 in a later preservation PR.
