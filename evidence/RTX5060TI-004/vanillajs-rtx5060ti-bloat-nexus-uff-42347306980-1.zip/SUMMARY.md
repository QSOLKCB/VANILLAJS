# RTX 5060 Ti — three pinned original sources + CPU numerical kernels

Status: PASS
Candidate: 05883459a6ffd355c3336a03f1085bb5d8ac5d5f

| Historical receipt | Pinned source | Native GPU |
| --- | --- | --- |
| RTX5060TI-001 | 240617e8bc1a935f05eaf75a10531f194f72a173 | PASS |
| RTX5060TI-002 | b39b0bd0db5ba9b467b9e47aede4edc4dd156e9f | PASS |
| RTX5060TI-003 | 3f5518a168652a003e8db9aa6dc0371ddb4782ea | PASS |

New serial workloads: 8 scenarios (range, replay, NEXUS, Kepler).
Seven measured samples per scenario and strict input/state checks.
This is CPU numerical evidence, not RTX GPU compute.
No historical GPU FPS speedup claim is implied.
Preserve exact artifact bytes in a separate evidence PR.
