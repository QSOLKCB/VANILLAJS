# VANILLAJS — local RTX 5060 Ti full-path validation

Baseline: 3f5518a168652a003e8db9aa6dc0371ddb4782ea
Candidate: 05883459a6ffd355c3336a03f1085bb5d8ac5d5f
Native WebGL: ANGLE (NVIDIA Corporation, NVIDIA GeForce RTX 5060 Ti/PCIe/SSE2, OpenGL ES 3.2)
NVIDIA driver: 595.99.02

| Metric | Baseline median | Candidate median | Scope |
| --- | ---: | ---: | --- |
| CPU static geometry preparation | 56.900 | 14.300 | ms per recorded trial |
| CPU static collision queries, index-build included | 74.800 | 2.300 | ms per recorded trial |
| Actual FPS Lab JS callback | 0.200 | 0.200 | ms per recorded trial |
| Actual FPS Lab frame interval p95 | 16.800 | 16.800 | ms per recorded trial |
| FPS Lab GPU upload submitted bytes | 1486080.000 | 1486080.000 | bytes per recorded trial |
| FPS Lab draw calls | 960.000 | 960.000 | calls per recorded trial |

Native pixel parity: PASS on three deterministic GPU scenes.
CPU geometry and canonical collision receipt hashes: PASS across seven paired trials.

Memory: CDP *statistical sampled allocation* baseline 55392668 bytes, candidate 55035596 bytes; NOT exact process allocation.

Full raw samples and instrument limitations are in report.json.
This file is an observation receipt, not a release/merge gate or independent hardware attestation.
